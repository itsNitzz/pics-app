import axios from 'axios';

export default axios.create({
    baseURL:'https://api.unsplash.com',
    headers:{
        Authorization: 'Client-ID H7RaxpvMPYKPxXZsHQoqkryNWU4Ft8Dfxi1LXiQ2rhw'
    }
});